function channel_change(channel_id){
	document.getElementById('channel_id_get_get').innerHTML = channel_id;
	console.log(channel_id);
	const message_box = document.querySelector("#fast");
	message_box.remove();
	fetch('database/database_'+channel_id+'.html')
	.then((res) => {
	return res.text();
	})
	.then((text) =>{
		const box = document.querySelector("#message_box");
  	div = document.createElement("div");
    div.id = 'fast';
		div.innerHTML = text;
		box.insertBefore(div, box.firstChild);
	});
	return channel_id;

		$.cookie('channel_id',channel_id,{expires:1800, path:'/', domain:'beets.niions.repl.co', secure:true});
}



/*
<div id="fast">
</div>
<div id="message">   <-これを作って、ここの関数で消す
</div>
*/
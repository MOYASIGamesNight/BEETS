var channel_id = "100016";
var now = new Date();

//安全処理 XSS対策
function htmlspecialchars(unsafeText){
  if(typeof unsafeText !== 'string'){
    return unsafeText;
  }
  return unsafeText.replace(
    /[&'`"<>]/g, 
    function(match) {
      return {
        '&': '&amp;',
        "'": '&#x27;',
        '`': '&#x60;',
        '"': '&quot;',
        '<': '&lt;',
        '>': '&gt;',
      }[match]
    }
  );
}

var cookies = document.cookie;
var cookieItem = cookies.split(";");

var cookieValue = "";
for (i = 0; i < cookieItem.length; i++) {
  var elem = cookieItem[i].split("=");
  if (elem[0].trim() == "username") {
    cookieValue = unescape(elem[1]);
  } else {
    continue;
  }
}
let myCookie = cookieValue;

  //-------------------------------------
  // Socket.ioサーバへ接続
  //-------------------------------------
  const socket = io();

	document.getElementById("create_channel_channel").onclick = function(){
		const create_box = document.querySelector("#create_channel");
  	var create_div = document.createElement("div");
    create_div.id = "create_form";
		create_div.innerHTML = '<input type="text" id="create_channel_id">';
    create_box.insertBefore(create_div, create_box.firstChild);
		
		//document.getElementById("create_button").onclick = function(){
		document.getElementById("create_channel_id").onkeydown = function(event){
			if(event.shiftKey) {
			  if (event.key === 'Enter') {
          var create_channel_id = document.querySelector("#create_channel_id");
					if(create_channel_id.value === ""){
      			return(false);
			    }
					socket.emit("post", {create_channel_id: create_channel_id.value});
					const create_form = document.querySelector("#create_form");
					create_form.remove();
					console.log(create_channel_id.value);
	
					//
					fetch('database/channel_list.html')
  				.then((res) => {
					return res.text();
			  	})
					.then((text) =>{
						document.getElementById('channel_list_list').innerHTML = text;
					});
      	}
			}
		};
	};
  //[イベント] フォームが送信された

	document.getElementById("send_message").onclick = function(){
    // 入力内容を取得する
		const msg = document.getElementById('msg');
		let msg_message = htmlspecialchars(msg.value);
    if(msg_message === ""){
      return(false);
    }

    var Hour = now.getHours();
    var Min = now.getMinutes();
    var Sec = now.getSeconds();

		if(msg_message.includes('.jpg') || msg_message.includes('.jpeg') || msg_message.includes('.gif') || msg_message.includes('.png') || msg_message.includes('.bmp')){
			const regexp_img = /(https?:\/\/[\w/:%#\$&\?\(\)~\.=\+\-]+)/g;
			msg_message = msg_message.replace(regexp_img, '<img src="$1" height="200px" onError="this.onerror=null;this.src='+"'https://beets.geekr.repl.co/assets/img/not-found.png'"+';" ><br>');
			console.log(msg_message);
		}else{
			const regexp_url = /(https?:\/\/[\w/:%#\$&\?\(\)~\.=\+\-]+)/g;
	  	msg_message = msg_message.replace(regexp_url, '<a href="$1"target="_blank">$1</a>');
			console.log(msg_message);
		}

		const regexp_at = /@+([a-zA-Z0-9亜-熙ぁ-んァ-ヶー-龥朗-鶴.\-_]+)/g;
  	msg_message = msg_message.replace(
    	regexp_at,
	    '<span id="atto">@$1</span>'
  	);
		console.log(msg_message);
		
		msg_message = msg_message.replace(
    	'⌘',
	    '<span id="hash"></span>'
  	);
		
    // Socket.ioサーバへ送信
		//channelは6桁の文字列で構成される
		console.log(channel_id);
    socket.emit("post", {text: msg_message, channel_id: channel_id, user: myCookie, time: Hour+':'+Min+':'+Sec});
		console.log(msg_message);
		
    // 発言フォームを空にする
    msg.value = "";
    document.querySelector("#msg").focus({
      preventScroll: true
    });
  }

  /**
   * [イベント] 誰かが発言した
   */
  socket.on("member-post", (msg)=>{
		if(msg.channel_id == channel_id){
			const box = document.querySelector("#fast");
	    const div = document.createElement("div");
  	  div.innerHTML = '<div class="message"><span class="name">'+`${msg.user}`+'</span><span class="time">'+msg.time+'</span><div class="main">'+`${msg.text}`+'</div></div>';
    	box.insertBefore(div, box.firstChild);
		}
  });

  /**
   * [イベント] ページの読込み完了
   */
  window.onload = ()=>{
		//document.addEventListener('keydown', keydown_ivent);
		document.getElementById('channel_id_get_get').innerHTML = channel_id;

		fetch('database/database_'+channel_id+'.html')
  	.then((res) => {
			return res.text();
  	})
		.then((text) =>{
			const box = document.querySelector("#message_box");
    	const div = document.createElement("div");
			div.id = 'fast';
  	  div.innerHTML = text;
    	box.insertBefore(div, box.firstChild);
		});
		
		fetch('database/channel_list.html')
  	.then((res) => {
			return res.text();
  	})
		.then((text) =>{
			const box = document.querySelector("#channel_list");
    	var div = document.createElement("div");
			div.id="channel_list_list";
  	  div.innerHTML = text;
    	box.insertBefore(div, box.firstChild);
		});

		/*
		let element = document.documentElement;
		let bottom = element.scrollHeight;

		let speed = 400;
                
		window.scroll({
      top: bottom,
      behavior: "smooth"
		});
		*/
		
		window.setTimeout(function(){
    	const loader = document.getElementById('loader');
    	loader.classList.add('loaded');
		}, 1000);
		window.setTimeout(function(){
    	const loaded = document.getElementById('loader');
			loaded.remove();
      var x = window.scrollX, y = window.scrollY;
      document.querySelector("#msg").focus();
      window.scrollTo(x, y);
		}, 1500);

  }
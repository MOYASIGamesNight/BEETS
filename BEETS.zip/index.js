const fs = require('fs');
const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http);

/**
 * "/"にアクセスがあったらindex.htmlを返却
 */

app.use(express.static("app"));
/**
 * [イベント] ユーザーが接続
 */
io.on("connection", (socket) => {
	console.log("online");

	socket.on("post", (msg) => {
		io.emit("member-post", msg);
		if (msg.create_channel_id) {
			create_channel_id = msg.create_channel_id;
			console.log(msg.create_channel_id);
			fs.readFile("app/database/new_channel_id.txt", "utf-8", (err, data) => {
				if (err) throw err;
				channel_server_id = Number(data);
				console.log("data:" + channel_server_id);
				var channel_server_id = channel_server_id + 1;

				fs.appendFile("app/database/channel_list.html", '<input type="button" value="#' + create_channel_id + '" onclick="channel_id = channel_change(' + "'" + channel_server_id + "'" + ');">', (err) => {
					if (err) throw err;
					fs.writeFile("app/database/new_channel_id.txt", String(channel_server_id), (err) => {
						if (err) throw err;

            fs.writeFile("app/database/database_" + channel_server_id + ".html", '', (err) => {
              if (err) throw err;
              console.log('create done.');
            });
            
					});
				});
			});
		} else {
			fs.readFile("app/database/database_" + msg.channel_id + ".html", "utf-8", (err, data) => {
				if (err) throw err;
				//console.log('can get channel.');
				fs.writeFile("app/database/database_" + msg.channel_id + ".html", '<div class="message"><span class="name">' + `${msg.user}` + '</span><span class="time">'+msg.time+'</span><div class="main">' + `${msg.text}` + '</div></div>\n' + data, (err) => {
					if (err) throw err;
					console.log("done");
					//console.log(msg.channel_id);
				});
			});
		}
	});
});

/**
 * 3000番でサーバを起動する
 */
http.listen(3000, () => {
	console.log("listening on *:3000");
});